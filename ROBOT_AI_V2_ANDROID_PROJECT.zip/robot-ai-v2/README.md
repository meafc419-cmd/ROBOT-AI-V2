# ROBOT AI V2 — Android starter

Versi awal aplikasi Android untuk latihan. Fitur yang tersedia: layar login demo dan kalkulator hitungan dasar. Belum terhubung ke layanan AI generatif atau OCR/foto soal.

Demo login: `belajar` / `robot123` (kredensial tertanam hanya untuk prototipe; bukan autentikasi aman untuk produksi).

## Build
Gunakan JDK 17 dan Gradle 8.9, lalu jalankan `gradle assembleDebug`. APK akan berada di `app/build/outputs/apk/debug/app-debug.apk`. GitHub Actions dapat menghasilkan APK debug yang ditandatangani dengan debug key otomatis.
