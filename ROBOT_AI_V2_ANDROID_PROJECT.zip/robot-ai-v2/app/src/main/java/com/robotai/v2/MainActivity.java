package com.robotai.v2;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,21,34), panel = Color.rgb(28,36,54), accent = Color.rgb(91,108,255);
    private LinearLayout root;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(0xffaab2c4);
        e.setPadding(dp(14), dp(10), dp(14), dp(10)); e.setBackgroundColor(panel); return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent)); return b;
    }
    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(28),dp(22),dp(20)); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
    }
    @Override public void onCreate(Bundle state) { super.onCreate(state); showLogin(); }
    private void showLogin() {
        base(); root.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("🤖  ROBOT AI V2", 28, true); logo.setGravity(Gravity.CENTER); root.addView(logo, new LinearLayout.LayoutParams(-1, dp(80)));
        TextView sub = text("Asisten belajar dan latihan soal", 15, false); sub.setGravity(Gravity.CENTER); root.addView(sub);
        addSpace(30); root.addView(text("Masuk ke aplikasi",20,true)); addSpace(12);
        EditText user = field("Username"); root.addView(user, match()); addSpace(10);
        EditText pass = field("Password"); pass.setInputType(0x81); root.addView(pass, match()); addSpace(18);
        Button login = button("Masuk"); root.addView(login, match());
        TextView info = text("Akun demo: belajar  |  Kata sandi: robot123", 12, false); info.setGravity(Gravity.CENTER); root.addView(info); addSpace(10);
        TextView msg = text("",13,false); root.addView(msg);
        login.setOnClickListener(v -> { if (user.getText().toString().equals("belajar") && pass.getText().toString().equals("robot123")) showHome(); else msg.setText("Username atau password salah."); });
    }
    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(-1, dp(52)); }
    private void addSpace(int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1,dp(h))); }
    private void showHome() {
        base(); root.addView(text("ROBOT AI V2",26,true)); addSpace(6);
        root.addView(text("Teman belajar untuk memahami soal",14,false)); addSpace(22);
        root.addView(text("Masukkan soal atau hitungan",18,true)); addSpace(10);
        EditText question = new EditText(this); question.setTextColor(Color.WHITE); question.setHintTextColor(0xffaab2c4); question.setHint("Contoh: 25 + 17 atau tulis pertanyaan..."); question.setGravity(Gravity.TOP|Gravity.START); question.setMinLines(4); question.setPadding(dp(14),dp(12),dp(14),dp(12)); question.setBackgroundColor(panel); root.addView(question,new LinearLayout.LayoutParams(-1,dp(130)));
        addSpace(12); Button solve = button("Jawab / Hitung"); root.addView(solve,match()); addSpace(14);
        TextView answer = text("Jawaban akan muncul di sini.",16,false); answer.setPadding(dp(14),dp(14),dp(14),dp(14)); answer.setBackgroundColor(panel); root.addView(answer,new LinearLayout.LayoutParams(-1,-2));
        solve.setOnClickListener(v -> { String q=question.getText().toString().trim(); if(q.isEmpty()){answer.setText("Silakan masukkan soal terlebih dahulu.");return;} try { double val=eval(q); answer.setText("Hasil: "+(val==(long)val?String.valueOf((long)val):String.valueOf(val))+"\n\nPeriksa kembali langkah pengerjaan dan pahami konsepnya."); } catch(Exception ex) { answer.setText("Fitur saat ini mendukung hitungan dasar (+, -, *, /) saja. Untuk menjawab pertanyaan umum dan membaca foto soal, diperlukan layanan AI/OCR yang akan dihubungkan pada tahap berikutnya."); } });
        addSpace(18); TextView note=text("Catatan: ini versi awal untuk latihan. Belum terhubung ke AI online dan belum mendukung pemindaian foto soal.",12,false); root.addView(note);
        addSpace(12); Button logout=button("Keluar"); root.addView(logout,match()); logout.setOnClickListener(v->showLogin());
    }
    private double eval(String s) {
        String x=s.replace(" ",""); if(!x.matches("[0-9+\\-*/().]+")) throw new IllegalArgumentException();
        return new Object(){ int p=-1,c; void next(){c=++p<x.length()?x.charAt(p):-1;} boolean eat(int k){while(c==' ')next();if(c==k){next();return true;}return false;} double parse(){next();double v=expr();if(p<x.length())throw new RuntimeException();return v;} double expr(){double v=term();for(;;){if(eat('+'))v+=term();else if(eat('-'))v-=term();else return v;}} double term(){double v=factor();for(;;){if(eat('*'))v*=factor();else if(eat('/'))v/=factor();else return v;}} double factor(){if(eat('+'))return factor();if(eat('-'))return -factor();double v;int start=p;if(eat('(')){v=expr();if(!eat(')'))throw new RuntimeException();}else{while((c>='0'&&c<='9')||c=='.')next();if(start==p)throw new RuntimeException();v=Double.parseDouble(x.substring(start,p));}return v;} }.parse();
    }
}
